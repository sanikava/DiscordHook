from guizero import *
from discord_webhook import DiscordWebhook
import os
import time

def clicked():

         myfile = open("Message.txt", "rt")
         message = myfile.read()
         myfile.close() 
         
         webhook = DiscordWebhook(url=Link, content=message)
         response = webhook.execute()
         
         message = Text(gui, text="Message Sent", size=9)

myfile = open("Link.txt", "rt")
Link = myfile.read()
myfile.close()


def read():
         myfile = open("Message.txt", "rt")
         message = myfile.read()
         myfile.close()
         
def save():
         file = open("Message.txt","w") 
         file.write(box.value) 
         file.close()
         clicked()

def savelink():
         file = open("Link.txt","w") 
         file.write(linkbox.value) 
         file.close()
         message = Text(gui, text="Saved link", size=9)

def credits_function():
         gui.info("Credits", "DiscordHook was made by fortbrleaks (Thomas Keig)")
def socials_function():
         gui.info("Connect with me!", "My Social Media \n\nTwitter: https://twitter.com/fortbrleaks \nInstagram: https://instagram.com/fortbrleaks \nYoutube: https://youtube.com/fortbrleaks \nDiscord Server: https://discord.gg/HsqYa5x")
def git_function():
         gui.info("Github Page", "You can download updates at https://www.github.com/thomaskeig/DiscordHook")

gui = App(title='DiscordHook | v1.01') # Window title

menubar = MenuBar(gui,
                  toplevel=["File", "Github"],
                  options=[
                      [ ["Credits", credits_function], ["Connect with me", socials_function] ],
                      [ ["Github page", git_function], ]
                  ])

gui.info("Welcome", "Thank you for using DiscordHook \n\nYou can support me in the Fortnite Item Shop by using code creator code: FBR \n\nDiscord Server: https://discord.gg/HsqYa5x \n\nClick OK below to begin")
#Info box

message = Text(gui, text="DiscordHook - A discord webhook sender", size=15)
message = Text(gui, text="by fortbrleaks", size=11)

message = Text(gui, text="", size=11)

message = Text(gui, text="Current bugs:", size=12)
message = Text(gui, text="Save button for webhook link not functioning properly. \nIt will be re-added when it works again...", size=10)
message = Text(gui, text="", size=10)

message = Text(gui, text="Your webhook link:", size=13)
linkbox = TextBox(gui, width=50, multiline=True, scrollbar=True, height=1)
linkbox.value=Link
linkbox.after(100, read)

savebutton = PushButton(gui, command=savelink, text='Save Link', visible=False)
savebutton.width=5
savebutton.height=1

message = Text(gui, text="", size=10)


message = Text(gui, text="Enter message here:", size=13)

box = TextBox(gui, width=50, multiline=True, scrollbar=True, height=10)
box.value='Replace this with message text...'
box.after(100, read)


message = Text(gui, text="", size=10)

button = PushButton(gui, command=save, text='Send')
button.width=5
button.height=1

message = Text(gui, text="Log:", font='Arial', size=13)

print("Launched GUI")
gui.display()
